	package com.test.user;
	
	import java.io.File;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;
	import java.util.Map;
	import org.testng.ITestContext;
	import org.testng.annotations.AfterTest;
	import org.testng.annotations.BeforeSuite;
	import org.apache.commons.lang3.ObjectUtils.Null;
	import org.apache.poi.hssf.record.PageBreakRecord.Break;
	import org.testng.*;
	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Test;
	import com.BasePackage.Base_Class;
	import com.Utility.Log;
	import com.aventstack.extentreports.MediaEntityBuilder;
	import com.aventstack.extentreports.Status;
	import com.extentReports.ExtentManager;
	import com.extentReports.ExtentTestManager;
	import com.google.common.base.Throwables;
	import com.listeners.TestListener;
	
	public class CareerOpportunities_scenarios extends Base_Class  {
	
		Base_Class Base_Class;
		com.pages.Home Home;
		com.pages.Joinnow joinnow;
		Log log;
		TestListener TestListener;
		com.Utility.ScreenShot screenShot;
		com.pages.Employment Employment;
		com.pages.FreePass FreePass;
		com.pages.CareerOpportunity CareerOpportunity;
		
		@BeforeSuite
		public void reference() {
			Base_Class = new Base_Class();
			log = new Log();
			TestListener = new TestListener();
			screenShot = new com.Utility.ScreenShot(null);
			Home = new com.pages.Home();
			joinnow = new com.pages.Joinnow();
			Employment = new com.pages.Employment();
			FreePass = new com.pages.FreePass();
			
			CareerOpportunity = new com.pages.CareerOpportunity();
		}
		
		@Test(dataProvider = "TestData")
		public void RUNALL(Map<Object, Object> testdata, ITestContext context) throws Throwable {
	
			try {
	
				if (testdata.get("Run").toString().equalsIgnoreCase("Yes")) {
					String fileName;
					ExtentTestManager.startTest(testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " running Starting ***");
					Log.info("*** Running test method " + testdata.get("TestScenario").toString() + "...");
					ExtentTestManager.getTest().log(Status.PASS, "*** Running test method " + testdata.get("TestScenario").toString() + "...");
				
					String Change_brand_name=testdata.get("Change_brand_name").toString();
					if(testdata.get("TextMessage").toString().trim().equalsIgnoreCase("Change_Brand".trim())) {
						
						Base_Class.setup_Change_brand();
						if(!Change_brand_name.isBlank() && !Change_brand_name.isEmpty()) Base_Class.Change_Brand(Change_brand_name);
						
					else {
						
						throw new Exception("please provide brand name to change the brand");
					
						}
						
						driver.quit();
						
					}
					
					else {
						Base_Class.setup();
					}
	
					ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered into Application URL ");
	
	
					String Dropdown_values=testdata.get("Dropdown_values").toString();
	
					String Country =testdata.get("Country").toString();
					String Ratesoramenities =testdata.get("Rates/amenities").toString();
					String Club_name =testdata.get("Club_name").toString();
					
					String Add_amenities =testdata.get("Add_amenities").toString();
					String Included_amenities =testdata.get("Included_amenities").toString();
				
					String Amount_details =testdata.get("Amount_details").toString();
					String rates_details =testdata.get("Rates_details").toString();
					String plan_rates =testdata.get("Plan_rates").toString();
					
					
					
					
					String Text_input =testdata.get("Text_input").toString();
		
					
					String Number_of_Persons1 =testdata.get("Number_of_Persons1").toString();
					String Initiation_Fee =testdata.get("Initiation_Fee").toString();
					String Billing_Frequency =testdata.get("Billing_Frequency").toString();				
					String Initial_Term =testdata.get("Initial_Term").toString();
					String Prepayment =testdata.get("Prepayment").toString();
					String First_Month_Dues =testdata.get("First_Month_Dues").toString();
					String Last_Month_Dues =testdata.get("Last_Month_Dues").toString();
					String Total_initial_Payment =testdata.get("Total_initial_Payment").toString();	
					String Annual_Fee_Per_Person =testdata.get("Annual_Fee_Per_Person").toString();
					
					String Everemployed_rdobtn =testdata.get("Everemployed_rdobtn").toString();
					String Date_to_begin =testdata.get("Date_to_begin").toString();
					String Languages =testdata.get("Languages").toString();
					String Work_time =testdata.get("Work_time").toString();
					String Url =testdata.get("Url").toString();
					String additional_input =testdata.get("additional_input").toString();
					String input_data =testdata.get("input_data").toString();
					String input_data1 =testdata.get("input_data1").toString();
					String input_data2 =testdata.get("input_data2").toString();
					String input_data3 =testdata.get("input_data3").toString();
					String input_data4 =testdata.get("input_data4").toString();
					String input_data5 =testdata.get("input_data5").toString();
					String input_data6 =testdata.get("input_data6").toString();
					String IP_Address =testdata.get("IP_Address").toString();
					
					String File_name =testdata.get("File_name").toString();
					
					String Job_short_des =testdata.get("Job_short_des").toString();
					String Job_long_des =testdata.get("Job_long_des").toString();
					String F_Name =testdata.get("F_Name").toString();
					String L_Name =testdata.get("L_Name").toString();
					String Full_name =testdata.get("Full_name").toString();
					String Phone =testdata.get("Member_Phone").toString();
					String Email =testdata.get("Email").toString();
					String Address =testdata.get("Member_address").toString();
	//				job_short_des
					String City =testdata.get("Member_City").toString();
					
					String E_EducationLeve_Dropdown = testdata.get("E_EducationLeve_Dropdown").toString();
	
					String Aerobics_Instructor_Exp_DD = testdata.get("Aerobics_Instructor_Exp_DD").toString();
					String Time_period_DD = testdata.get("Time_period_DD").toString();
					String Club_Employer_DD = testdata.get("Club_Employer_DD").toString();
					String Class_per_week = testdata.get("Class_per_week").toString();
					
					String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
					String PriorEmploymentWhyResigned_ip = testdata.get("PriorEmploymentWhyResigned_ip").toString();
					String EmploymentWhyLeaveCurrent_ip = testdata.get("EmploymentWhyLeaveCurrent_ip").toString();
					String EmploymentWhyReapply_ip = testdata.get("EmploymentWhyReapply_ip").toString();
					String EmploymentWhatLike_ip = testdata.get("EmploymentWhatLike_ip").toString();
					String EmploymentWhatDislike_ip = testdata.get("EmploymentWhatDislike_ip").toString();
					
					String EmploymentSuccess_ip = testdata.get("EmploymentSuccess_ip").toString();
					String EmploymentWhyResignInFuture_ip = testdata.get("EmploymentWhyResignInFuture_ip").toString();
					String Gender_dd = testdata.get("Gender_dd").toString();
					String RaceEthnicity_dd = testdata.get("RaceEthnicity_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				
					String Personal_Training_ExperienceDPValues = testdata.get("Personal_Training_ExperienceDPValues").toString();
					String Certification_IssuedByDPValues = testdata.get("Certification_IssuedByDPValues").toString();
					String Hold_cert_GT_AC_ratio_button = testdata.get("Hold_cert_GT_AC_ratio_button").toString();
					String Certified_In_DD = testdata.get("Certified_In_DD").toString();
					String Certificate_No = testdata.get("Certificate_No").toString();
					String Emp_gap = testdata.get("Emp_gap").toString();
					String Employer_name = testdata.get("Employer_name").toString();
					String Supervisor_name = testdata.get("Supervisor_name").toString();
					String From_date = testdata.get("From_date").toString();
					String To_date = testdata.get("To_date").toString();
					String Job_title = testdata.get("Job_title").toString();
					String Leaving_Reason = testdata.get("Leaving_Reason").toString();
					String Emp_details = testdata.get("Emp_details").toString();
					String Can_contact_radio_button = testdata.get("Can_contact_radio_button").toString();
					
					
					String Club_phone =testdata.get("Club_phone").toString();
					String Club_zip =testdata.get("Club_zip").toString();
					String Club_Address =testdata.get("Club_Address").toString();
					String Club_city =testdata.get("Club_city").toString();
	//				
					String State =testdata.get("State").toString();
					String Zipcode =testdata.get("Member_Zipcode").toString();
					String Radius_travel_to_work =testdata.get("Radius_travel_to_work").toString();
					String How_hear_abt_us =testdata.get("How_hear_abt_us").toString();
					String Radiobtn18YearsOld =testdata.get("Radiobtn18YearsOld").toString();
					String Payment_type =testdata.get("Payment_type").toString();
					String Card_number  =testdata.get("Card_number").toString();
					
					String Ex_month =testdata.get("Ex_month").toString();
					String Ex_year  =testdata.get("Ex_year").toString();
					
					String Routing_number  =testdata.get("Routing_number").toString();
					String Account_number =testdata.get("Account_number").toString();
					String Card_name =testdata.get("Card_name").toString();
					String Checkbox_class_formats =testdata.get("Checkbox_class_formats").toString();

					String No_Prev_emp_chk_box =testdata.get("No_Prev_emp_chk_box").toString();
				
					
					
					
					
							
					switch (testdata.get("TextMessage").toString()) {
					
					
					// Career Opportunities - 
					


						case "text_EmploymentApplication":

							context.setAttribute("fileName", "text_EmploymentApplication");
							CareerOpportunity.TC_23_CP_Validate_text_EmploymentApplication(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "text_EmploymentApplication");
							driver.quit();
							break;
							
						case "CP_URL_click_PersonalTrainerApplyhere":

							context.setAttribute("fileName", "CP_URL_click_PersonalTrainerApplyhere");
							CareerOpportunity.TC_38_CP_Validate_url_clickofPersonalTrainerApplyhere(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "CP_URL_click_PersonalTrainerApplyhere");
							driver.quit();
							break;

						case "text_Below_EmploymentApp":

							context.setAttribute("fileName", "text_Below_EmploymentApp");
							CareerOpportunity.TC_24_CP_Validate_Text_Below_EmploymentApp(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "text_Below_EmploymentApp");
							driver.quit();
							break;

							
						case "Hyperlink_www.lafitness.com":

							context.setAttribute("fileName", "Hyperlink_www.lafitness.com");
							CareerOpportunity.TC_25_CP_Validate_Hyperlink_wwwfitnesscom(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "Hyperlink_www.lafitness.com");
							driver.quit();
							break;
							
						case "Text_AppInfo_ContandLocInfo":

							context.setAttribute("fileName", "Text_AppInfo_ContandLocInfo");
							CareerOpportunity.TC_26_CP_Validate_Text_AppInfo_ContandLocInfo(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "Text_AppInfo_ContandLocInfo");
							driver.quit();
							break;
							
						case "Field_Validation":

							context.setAttribute("fileName", "Field_Validation");
							CareerOpportunity.TC_27_CP_Validate_mandatoryFields(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "Field_Validation");
							driver.quit();	
							break;
							
						case "Dropdown_HowDidUHearUs":

							context.setAttribute("fileName", "Dropdown_HowDidUHearUs");
							CareerOpportunity.TC_28_CP_Validate_Dropdownvalues_HowDidUhearUs(testdata.get("TextMessage").toString(),Dropdown_values);
							context.setAttribute("fileName", "Dropdown_HowDidUHearUs");
							driver.quit();	
							break;
							
						case "Radio_RU18":

							context.setAttribute("fileName", "Radio_RU18");
							CareerOpportunity.TC_29_CP_Validate_Radiobutton_RU18(testdata.get("TextMessage").toString(),Dropdown_values);
							context.setAttribute("fileName", "Radio_RU18");
							driver.quit();
							break;
							
						case "Text_FormatUSCanada":

							context.setAttribute("fileName", "Text_FormatUSCanada");
							CareerOpportunity.TC_30_CP_validate_Text_FormatUSCanada(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "Text_FormatUSCanada");
							driver.quit();
							break;
							
						case "Text_Miles":

							context.setAttribute("fileName", "Text_Miles");
							CareerOpportunity.TC_30_CP_validate_Text_Miles(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "Text_Miles");
							driver.quit();
							break;
							
						case "Errormsg_CellPhone":

							context.setAttribute("fileName", "Errormsg_CellPhone");
							CareerOpportunity.TC_31_CP_Validate_ErrorMsg_CellPhone(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "Errormsg_CellPhone");
							driver.quit();
							break;
							
							
						case "Button_NextStep":

							context.setAttribute("fileName", "Button_NextStep");
							CareerOpportunity.TC_32_CP_Validate_Button_NextStep(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "Button_NextStep");
							driver.quit();
							break;
							
						case "CP_Field_inputs":

							context.setAttribute("fileName", "CP_Field_inputs");
							CareerOpportunity.TC_33_CP_Validate_Field_Input(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode );
							context.setAttribute("fileName", "CP_Field_inputs");
							driver.quit();
							break;
							
							
						case "CP_NextButtonClick_ApplicantInfo":

							context.setAttribute("fileName", "CP_NextButtonClick_ApplicantInfo");
							CareerOpportunity.TC_34_CP_Validate_Nextbutton_ClickofApplicantinfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode );
							context.setAttribute("fileName", "CP_NextButtonClick_ApplicantInfo");
							driver.quit();
							break;

						case "CP_Text_EducationInfo":

							context.setAttribute("fileName", "CP_Text_EducationInfo");
							CareerOpportunity.TC_35_CP_Validate_Text_EducationInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input );
							context.setAttribute("fileName", "CP_Text_EducationInfo");
							driver.quit();
							break;
							
						case "Field_EducationLevel":

							context.setAttribute("fileName", "Field_EducationLevel");
							CareerOpportunity.TC_36_CP_Validate_Field_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input );
							context.setAttribute("fileName", "Field_EducationLevel");
							driver.quit();
							break;
							
						case "DropdownValues_EducationLevel":

							context.setAttribute("fileName", "DropdownValues_EducationLevel");
							CareerOpportunity.TC_37_CP_Validate_DropdownValues_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "DropdownValues_EducationLevel");
							driver.quit();
							break;
							
							
						case "CP_Select_RadioNo":

							context.setAttribute("fileName", "CP_Select_RadioNo");
							CareerOpportunity.TC_39_CP_Verify_YouMustBe18Years_popup_OnselectingRaiodNo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values);
							context.setAttribute("fileName", "CP_Select_RadioNo");
							driver.quit();
							break;
							
						case "CP_EL_ButtonsPerviousNext":

							context.setAttribute("fileName", "CP_EL_ButtonsPerviousNext");
							CareerOpportunity.TC_40_CP_Validate_EducationLevel_ButtonsPerviousNext(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode );
							context.setAttribute("fileName", "CP_EL_ButtonsPerviousNext");
							driver.quit();
							break;
							
						case "CP_EL_ClickofELPreviousbutton":

							context.setAttribute("fileName", "CP_EL_ClickofELPreviousbutton");
							CareerOpportunity.TC_41_CP_Validate_PreviousPage_ClickofELPreviousbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input );
							context.setAttribute("fileName", "CP_EL_ClickofELPreviousbutton");
							driver.quit();
							break;
							
						case "CP_EL_ClickofELNextbutton":

							context.setAttribute("fileName", "CP_EL_ClickofELNextbutton");
							CareerOpportunity.TC_42_CP_Validate_NextPage_ClickofELNextbutton(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "CP_EL_ClickofELNextbutton");
							driver.quit();
							break;

											
						case "CP_Text_ExperienceDetail":

							context.setAttribute("fileName", "CP_Text_ExperienceDetail");
							CareerOpportunity.TC_43_CP_Validate_Text_ExperienceDetail(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "CP_Text_ExperienceDetail");
							driver.quit();
							break;

							
						case "CP_Text_PersonalTrainer":

							context.setAttribute("fileName", "CP_Text_PersonalTrainer");
							CareerOpportunity.TC_44_CP_Validate_Text_PersonalTrainer(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "CP_Text_PersonalTrainer");
							driver.quit();
							break;
							
						case "CP_Field_PersonalTrainerCertificate":

							context.setAttribute("fileName", "CP_Field_PersonalTrainerCertificate");
							CareerOpportunity.TC_45_CP_Validate_Field_PersonalTrainerCertificate(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "CP_Field_PersonalTrainerCertificate");
							driver.quit();
							break;
						
						case "CP_Radio_HoldPersonalTrainer":

							context.setAttribute("fileName", "CP_Radio_HoldPersonalTrainer");
							CareerOpportunity.TC_46_CP_Validate_Radio_HoldPersonalTrainer(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "CP_Radio_HoldPersonalTrainer");
							driver.quit();
							break;
							
						case "CP_Link_PersonalTrainerCI":

							context.setAttribute("fileName", "CP_Link_PersonalTrainerCI");
							CareerOpportunity.TC_47_CP_Validate_Link_PersonalTrainerCI(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "CP_Link_PersonalTrainerCI");
							driver.quit();
							break;
							
							
						case "CP_Field_PersonalTrainingExp":

							context.setAttribute("fileName", "CP_Field_PersonalTrainingExp");
							CareerOpportunity.TC_48_CP_Validate_Field_PersonalTrainingExp(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "CP_Field_PersonalTrainingExp");
							driver.quit();
							break;
						
						case "CP_DropdownValues_PersonalTrainingExp":

							context.setAttribute("fileName", "CP_DropdownValues_PersonalTrainingExp");
							CareerOpportunity.TC_49_CP_Validate_Dropdownvalues_PersonalTrainingExp(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues );
							context.setAttribute("fileName", "CP_DropdownValues_PersonalTrainingExp");
							driver.quit();
							break;
							
						case "CP_Text_Pleaseselectnomorethan":

							context.setAttribute("fileName", "CP_Text_Pleaseselectnomorethan");
							CareerOpportunity.TC_50_CP_Validate_Text_Pleaseselectnomorethan(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues );
							context.setAttribute("fileName", "CP_Text_Pleaseselectnomorethan");
							driver.quit();
							break;
				
						case "CP_Fields_CertificationissuedCertificationNumber":

							context.setAttribute("fileName", "CP_Fields_CertificationissuedCertificationNumber");
							CareerOpportunity.TC_51_CP_Validate_Fields_CertificationissuedCertificationNumber(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues );
							context.setAttribute("fileName", "CP_Fields_CertificationissuedCertificationNumber");
							driver.quit();
							break;
							
						case "CP_DropdownValue_Certificationissued":

							context.setAttribute("fileName", "CP_DropdownValue_Certificationissued");
							CareerOpportunity.TC_52_CP_Validate_DropdownValue_Certificationissued(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_DropdownValue_Certificationissued");
							driver.quit();
							break;
							
							
						case "CP_Text_CertificateFilesDtl":

							context.setAttribute("fileName", "CP_Text_CertificateFilesDtl");
							CareerOpportunity.TC_53_CP_Validate_Text_CertificateFilesDtl(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_Text_CertificateFilesDtl");
							driver.quit();
							break;
							
						case "CP_PersonalTrainerFlow":

							context.setAttribute("fileName", "CP_PersonalTrainerFlow");
							CareerOpportunity.TC_54_CP_Validate_PersonalTrainerFlow(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_PersonalTrainerFlow");
							driver.quit();
							break;
							
						case "CP_Button_ChooseFileUpload":

							context.setAttribute("fileName", "CP_Button_ChooseFileUpload");
							CareerOpportunity.TC_55_CP_Validate_ChooseFileUpload(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_Button_ChooseFileUpload");
							driver.quit();
							break;
							
						case "CP_Select_CetificateNumber":

							context.setAttribute("fileName", "CP_Select_CetificateNumber");
							CareerOpportunity.TC_56_CP_Validate_SelectCertificate_Certinum(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_Select_CetificateNumber");
							driver.quit();
							break;
							
							
						case "CP_Button_AddCertificate":

							context.setAttribute("fileName", "CP_Button_AddCertificate");
							CareerOpportunity.TC_57_CP_Validate_Button_AddCertificate(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_Button_AddCertificate");
							driver.quit();
							break;
							
						case "CP_Click_AddCertificate":

							context.setAttribute("fileName", "CP_Button_AddCertificate");
							CareerOpportunity.TC_58_CP_Validate_Click_AddCertificate(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_Button_AddCertificate");
							driver.quit();
							break;


						case "CP_Button_RemoveIcon":

							context.setAttribute("fileName", "CP_Button_RemoveIcon");
							CareerOpportunity.TC_59_CP_Validate_Button_RemoveIcon(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_Button_RemoveIcon");
							driver.quit();
							break;
							
						case "CP_Click_RemoveIcon":

							context.setAttribute("fileName", "CP_Click_RemoveIcon");
							CareerOpportunity.TC_60_CP_Validate_Click_RemoveIcon(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_Click_RemoveIcon");
							driver.quit();
							break;
							
						case "CP_Button_PreviousNextExperInfopage":

							context.setAttribute("fileName", "CP_Button_PreviousNextExperInfopage");
							CareerOpportunity.TC_61_CP_Validate_Button_PreviousNextExperInfopage(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_Button_PreviousNextExperInfopage");
							driver.quit();	
							break;
							
						case "CP_Click_PreviousExperInfopage":

							context.setAttribute("fileName", "CP_Click_PreviousExperInfopage");
							CareerOpportunity.TC_62_CP_Validate_Click_PreviousExperInfopage(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_Click_PreviousExperInfopage");
							driver.quit();	
							break;
							
						case "CP_Click_NextExperInfopage":

							context.setAttribute("fileName", "CP_Click_NextExperInfopage");
							CareerOpportunity.TC_63_CP_Validate_Click_NextExperInfopage(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_Click_NextExperInfopage");
							driver.quit();	
							break;
							
						case "CP_Text_PreviousEmloyment":

							context.setAttribute("fileName", "CP_Text_PreviousEmloyment");
							CareerOpportunity.TC_64_CP_Validate_Text_PreviousEmployment_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_Text_PreviousEmloyment");
							driver.quit();	
							break;
							
						case "CP_Radi_NoPreviousEmpyIhvanemplyHisy_PT":

							context.setAttribute("fileName", "CP_Radi_NoPreviousEmpyIhvanemplyHisy_PT");
							CareerOpportunity.TC_65_Validate_Radi_NoPreviousEmpyIhvanemplyHisy_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_Radi_NoPreviousEmpyIhvanemplyHisy_PT");
							driver.quit();	
							break;
							
						case "CP_Checkb_IwillUploadResume_PT":

							context.setAttribute("fileName", "CP_Checkb_IwillUploadResume_PT");
							CareerOpportunity.TC_66_Validate_Checkb_IwillUploadResume_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_Checkb_IwillUploadResume_PT");
							driver.quit();	
							break;
							
						case "CP_Text_EnterEmploHisty_PT":

							context.setAttribute("fileName", "CP_Text_EnterEmploHisty_PT");
							CareerOpportunity.TC_67_Validate_Text_EnterEmploHisty_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_Text_EnterEmploHisty_PT");
							driver.quit();	
							break;
							
						case "CP_Text_PreviousEmployecurrent_PT":

							context.setAttribute("fileName", "CP_Text_PreviousEmployecurrent_PT");
							CareerOpportunity.TC_68_Validate_Text_PreviousEmployecurrent_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_Text_PreviousEmployecurrent_PT");
							driver.quit();	
							break;
							
						case "CP_Fields_EmploymentHistory_PT":

							context.setAttribute("fileName", "CP_Fields_EmploymentHistory_PT");
							CareerOpportunity.TC_69_Validate_Fields_EmploymentHistory_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_Fields_EmploymentHistory_PT");
							driver.quit();	
							break;

						case "CP_Text_Bespecific_PT":

							context.setAttribute("fileName", "CP_Text_Bespecific_PT");
							CareerOpportunity.TC_70_Validate_Text_Bespecific_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_Text_Bespecific_PT");
							driver.quit();	
							break;

						case "CP_Text_Listdjobsheld_PT":

							context.setAttribute("fileName", "CP_Text_Listdjobsheld_PT");
							CareerOpportunity.TC_71_Validate_Text_Listdjobsheld_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_Text_Listdjobsheld_PT");
							driver.quit();	
							break;

						case "CP_Button_AddEmployer#2_PT":

							context.setAttribute("fileName", "CP_Button_AddEmployer#2_PT");
							CareerOpportunity.TC_72_Validate_Button_AddEmployer2_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_Button_AddEmployer#2_PT");
							driver.quit();
							break;
							
						case "CP_TextFieldsonclick_AddEmployer#2_PT":

							context.setAttribute("fileName", "CP_TextFieldsonclick_AddEmployer#2_PT");
							CareerOpportunity.TC_73_Validate_TextFieldsonclick_AddEmployer2_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_TextFieldsonclick_AddEmployer#2_PT");
							driver.quit();
							break;
							
						case "CP_onclick_RemoveEmployer2_PT":

							context.setAttribute("fileName", "CP_onclick_RemoveEmployer2_PT");
							CareerOpportunity.TC_74_Validate_onclick_RemoveEmployer2_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_onclick_RemoveEmployer2_PT");
							driver.quit();
							break;
							
						case "CP_FieldInput_Employmenthistory_PT":

							context.setAttribute("fileName", "CP_FieldInput_Employmenthistory_PT");
							CareerOpportunity.TC_75_Validate_FieldInput_Employmenthistory_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_FieldInput_Employmenthistory_PT");
							driver.quit();
							break;
						
						case "NextButton_EmploymentHistory_PT":

							context.setAttribute("fileName", "NextButton_EmploymentHistory_PT");
							CareerOpportunity.TC_76_Validate_NextButton_EmploymentHistory_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "NextButton_EmploymentHistory_PT");
							driver.quit();
							break;
							
						case "CP_PreviousButton_EmploymentHistory_PT":

							context.setAttribute("fileName", "CP_PreviousButton_EmploymentHistory_PT");
							CareerOpportunity.TC_77_Validate_PreviousButton_EmploymentHistory_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_PreviousButton_EmploymentHistory_PT");
							driver.quit();
							break;
							
						case "CP_Text_Indicatelangucanspeck_PT":

							context.setAttribute("fileName", "CP_Text_Indicatelangucanspeck_PT");
							CareerOpportunity.TC_78_Validate_Text_Indicatelangucanspeck_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_Text_Indicatelangucanspeck_PT");
							driver.quit();
							break;
						
						case "CP_numof_languages_PT":

							context.setAttribute("fileName", "CP_numof_languages_PT");
							CareerOpportunity.TC_79_Validate_numof_languages_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_numof_languages_PT");
							driver.quit();
							break;
							
						case "CP_PreviousButton_LanguagesSkill_PT":

							context.setAttribute("fileName", "CP_PreviousButton_LanguagesSkill_PT");
							CareerOpportunity.TC_80_Validate_PreviousButton_LanguagesSkill_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_PreviousButton_LanguagesSkill_PT");
							driver.quit();
							break;
							
						case "CP_NextButton_LanguagesSkill_PT":

							context.setAttribute("fileName", "CP_NextButton_LanguagesSkill_PT");
							CareerOpportunity.TC_81_Validate_NextButton_LanguagesSkill_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_NextButton_LanguagesSkill_PT");
							driver.quit();
							break;
							
							
						case "CP_Text_CareerOppoyUqualifyForl_PT":

							context.setAttribute("fileName", "CP_Text_CareerOppoyUqualifyForl_PT");
							CareerOpportunity.TC_82_Validate_Text_CareerOppoyUqualifyForl_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_Text_CareerOppoyUqualifyForl_PT");
							driver.quit();
							break;
						
						case "CP_Fields_CareerOptions_PT":

							context.setAttribute("fileName", "CP_Fields_CareerOptions_PT");
							CareerOpportunity.TC_83_CP_Validate_Fields_CareerOptions_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_Fields_CareerOptions_PT");
							driver.quit();
							break;
							
						case "CP_FieldInput_ReasonForLeaving_PT":

							context.setAttribute("fileName", "CP_FieldInput_ReasonForLeaving_PT");
							CareerOpportunity.TC_91_Validate_FieldInput_ReasonForLeaving_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_FieldInput_ReasonForLeaving_PT");
							driver.quit();
							break;

							
						case "CP_CheckboxValues_ImIntrestedInWorking_PT":

							context.setAttribute("fileName", "CP_CheckboxValues_ImIntrestedInWorking_PT");
							CareerOpportunity.TC_84_CP_Validate_CheckboxValues_ImIntrestedInWorking_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_CheckboxValues_ImIntrestedInWorking_PT");
							driver.quit();
							break;
							
						case "CP_CheckboxValues_CheckboxValues_IwouldBConsideredFor_PT":

							context.setAttribute("fileName", "CP_CheckboxValues_CheckboxValues_IwouldBConsideredFor_PT");
							CareerOpportunity.TC_85_CP_Validate_CheckboxValues_IwouldBConsideredFor_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_CheckboxValues_CheckboxValues_IwouldBConsideredFor_PT");
							driver.quit();
							break;
							
						case "CP_RadioBtn_RuNowOrEverEmployed_PT":

							context.setAttribute("fileName", "CP_RadioBtn_RuNowOrEverEmployed_PT");
							CareerOpportunity.TC_86_CP_Validate_RadioBtn_RuNowOrEverEmployed_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_RadioBtn_RuNowOrEverEmployed_PT");
							driver.quit();
							break;
							
						case "CP_Text_BasedOnUrSelecteionsUhvRequested_PT":

							context.setAttribute("fileName", "CP_Text_BasedOnUrSelecteionsUhvRequested_PT");
							CareerOpportunity.TC_87_CP_Validate_Text_BasedOnUrSelecteionsUhvRequested_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_Text_BasedOnUrSelecteionsUhvRequested_PT");
							driver.quit();
							break;
							
						case "CP_Text_IfYesPlzComplete_PT":

							context.setAttribute("fileName", "CP_Text_IfYesPlzComplete_PT");
							CareerOpportunity.TC_88_CP_Validate_Text_IfYesPlzComplete_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_Text_IfYesPlzComplete_PT");
							driver.quit();
							break;
							
						case "CP_Text_RehireQuestionnaire_PT":

							context.setAttribute("fileName", "CP_Text_RehireQuestionnaire_PT");
							CareerOpportunity.TC_89_CP_Validate_Text_RehireQuestionnaire_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_Text_RehireQuestionnaire_PT");
							driver.quit();
							break;
							
						case "CP_Fields_RadioYes_RueverEmployed_PT":

							context.setAttribute("fileName", "CP_Fields_RadioYes_RueverEmployed_PT");
							CareerOpportunity.TC_90_CP_Validate_Fields_RadioYes_RueverEmployed_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_Fields_RadioYes_RueverEmployed_PT");
							driver.quit();
							break;
							
						case "CP_ChooseFile_EmploymentHistotypage":

							context.setAttribute("fileName", "CP_ChooseFile_EmploymentHistotypage");
							CareerOpportunity.TC_91_CP_Validate_ChooseFile_EmploymentHistotypage(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date );
							context.setAttribute("fileName", "CP_ChooseFile_EmploymentHistotypage");
							driver.quit();
							break;
							
						case "CP_DropValues_ReasonForLeaving_PT":

							context.setAttribute("fileName", "CP_DropValues_ReasonForLeaving_PT");
							CareerOpportunity.TC_92_CP_Validate_DropValues_ReasonForLeaving_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_DropValues_ReasonForLeaving_PT");
							driver.quit();
							break;	
							
							
						case "CP_ButtonPreviousStep_ReasonForLeaving_PT":

							context.setAttribute("fileName", "CP_ButtonPreviousStep_ReasonForLeaving_PT");
							CareerOpportunity.TC_93_CP_Validate_ButtonPreviousStep_ReasonForLeaving_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_ButtonPreviousStep_ReasonForLeaving_PT");
							driver.quit();
							break;	

						case "CP_ButtonNextStep_ReasonForLeaving_PT":

							context.setAttribute("fileName", "CP_ButtonNextStep_ReasonForLeaving_PT");
							CareerOpportunity.TC_94_CP_Validate_ButtonNextStep_ReasonForLeaving_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_ButtonNextStep_ReasonForLeaving_PT");
							driver.quit();
							break;	
							
						case "CP_Text_TheCompanyisan_PT":

							context.setAttribute("fileName", "CP_Text_TheCompanyisan_PT");
							CareerOpportunity.TC_95_CP_Validate_Text_TheCompanyisan_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_Text_TheCompanyisan_PT");
							driver.quit();
							break;	

						case "CP_Text_CompletionOfForm_PT":

							context.setAttribute("fileName", "CP_Text_CompletionOfForm_PT");
							CareerOpportunity.TC_96_CP_Validate_Text_CompletionOfForm_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_Text_CompletionOfForm_PT");
							driver.quit();
							break;	
							
						case "CP_Fields_EqualOpportunityEmploymentSection_PT":

							context.setAttribute("fileName", "CP_Fields_EqualOpportunityEmploymentSection_PT");
							CareerOpportunity.TC_97_CP_Validate_Fields_EqualOpportunityEmploymentSection_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_Fields_EqualOpportunityEmploymentSection_PT");
							driver.quit();
							break;	

						case "CP_DropdownValues_WtisUrGender_PT":

							context.setAttribute("fileName", "CP_DropdownValues_WtisUrGender_PT");
							CareerOpportunity.TC_98_CP_Validate_DropdownValues_WtisUrGender_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5 );
							context.setAttribute("fileName", "CP_DropdownValues_WtisUrGender_PT");
							driver.quit();
							break;	
							
						case "CP_DropdownValues_WtyourRaceEthnicOrigin_PT":

							context.setAttribute("fileName", "CP_DropdownValues_WtyourRaceEthnicOrigin_PT");
							CareerOpportunity.TC_99_CP_Validate_DropdownValues_WtyourRaceEthnicOrigin_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data4 );
							context.setAttribute("fileName", "CP_DropdownValues_WtyourRaceEthnicOrigin_PT");
							driver.quit();
							break;	
							
						case "CP_Text_HispanicorLatino_PT":

							context.setAttribute("fileName", "CP_Text_HispanicorLatino_PT");
							CareerOpportunity.TC_100_CP_Validate_Text_HispanicorLatino_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_Text_HispanicorLatino_PT");
							driver.quit();
							break;	
							
						case "CP_Text_WhiteNotHispanicorLatino_PT":

							context.setAttribute("fileName", "CP_Text_WhiteNotHispanicorLatino_PT");
							CareerOpportunity.TC_101_CP_Validate_Text_WhiteNotHispanicorLatino_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_Text_WhiteNotHispanicorLatino_PT");
							driver.quit();
							break;	
							
						case "CP_Text_BlackorAfricanAmerican_PT":

							context.setAttribute("fileName", "CP_Text_BlackorAfricanAmerican_PT");
							CareerOpportunity.TC_102_CP_Validate_Text_BlackorAfricanAmerican_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_Text_BlackorAfricanAmerican_PT");
							driver.quit();
							break;	
		
						case "CP_Text_NativeHawaiianorOtherPacific_PT":

							context.setAttribute("fileName", "CP_Text_NativeHawaiianorOtherPacific_PT");
							CareerOpportunity.TC_103_CP_Validate_Text_NativeHawaiianorOtherPacific_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_Text_NativeHawaiianorOtherPacific_PT");
							driver.quit();
							break;	
		
						case "CP_Text_AsianNotHispanicorLatino_PT":

							context.setAttribute("fileName", "CP_Text_AsianNotHispanicorLatino_PT");
							CareerOpportunity.TC_104_CP_Validate_Text_AsianNotHispanicorLatino_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_Text_AsianNotHispanicorLatino_PT");
							driver.quit();
							break;	

						case "CP_Text_AmericanIndianorAlaskanNative_PT":

							context.setAttribute("fileName", "CP_Text_AmericanIndianorAlaskanNative_PT");
							CareerOpportunity.TC_105_CP_Validate_Text_AmericanIndianorAlaskanNative_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_Text_AmericanIndianorAlaskanNative_PT");
							driver.quit();
							break;	

						case "CP_Text_Text_Allpersonswho_PT":

							context.setAttribute("fileName", "CP_Text_Text_Allpersonswho_PT");
							CareerOpportunity.TC_106_CP_Validate_Text_Allpersonswho_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "CP_Text_Text_Allpersonswho_PT");
							driver.quit();
							break;	

						case "Radiobtn_DoyouwishtoCompleteThisForm_PT":

							context.setAttribute("fileName", "Radiobtn_DoyouwishtoCompleteThisForm_PT");
							CareerOpportunity.TC_107_CP_Validate_Radiobtn_DoyouwishtoCompleteThisForm_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "Radiobtn_DoyouwishtoCompleteThisForm_PT");
							driver.quit();
							break;	

						case "Fieldinputs_EqualOpportunityEmploymentpage_PT":

							context.setAttribute("fileName", "Fieldinputs_EqualOpportunityEmploymentpage_PT");
							CareerOpportunity.TC_108_CP_Validate_Fieldinputs_EqualOpportunityEmploymentpage_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "Fieldinputs_EqualOpportunityEmploymentpage_PT");
							driver.quit();
							break;	

						case "CP_Nextbtn_EqualOpportunityEmploymentpage_PT":

							context.setAttribute("fileName", "CP_Nextbtn_EqualOpportunityEmploymentpage_PT");
							CareerOpportunity.TC_109_CP_Validate_Nextbtn_EqualOpportunityEmploymentpage_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "CP_Nextbtn_EqualOpportunityEmploymentpage_PT");
							driver.quit();
							break;	
		
						case "CP_Previbtn_EqualOpportunityEmploymentpage_PT":

							context.setAttribute("fileName", "CP_Previbtn_EqualOpportunityEmploymentpage_PT");
							CareerOpportunity.TC_110_CP_Validate_Previbtn_EqualOpportunityEmploymentpage_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "CP_Previbtn_EqualOpportunityEmploymentpage_PT");
							driver.quit();
							break;	
							
						case "CP_Text_ThisApplicationCompleteParaOnApplicantStatement_PT":

							context.setAttribute("fileName", "CP_Text_ThisApplicationCompleteParaOnApplicantStatement_PT");
							CareerOpportunity.TC_111_CP_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "CP_Text_ThisApplicationCompleteParaOnApplicantStatement_PT");
							driver.quit();
							break;
							
						case "CP_input_FirstNameLastName_acknowledgelineofApplicantStatementpage_PT":

							context.setAttribute("fileName", "CP_input_FirstNameLastName_acknowledgelineofApplicantStatementpage_PT");
							CareerOpportunity.TC_112_CP_input_FirstNameLastName_acknowledgelineofApplicantStatementpage_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "CP_input_FirstNameLastName_acknowledgelineofApplicantStatementpage_PT");
							driver.quit();
							break;	

						case "CP_Text_Iacknowledge_ApplicantStatementpage_PT":

							context.setAttribute("fileName", "CP_Text_Iacknowledge_ApplicantStatementpage_PT");
							CareerOpportunity.TC_113_CP_Validate_text_Iacknowledge_ApplicantStatementpage_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "CP_Text_Iacknowledge_ApplicantStatementpage_PT");
							driver.quit();
							break;	

							
						case "CP_Previbtn_ApplicantStatementpage_PT":

							context.setAttribute("fileName", "CP_Previbtn_ApplicantStatementpage_PT");
							CareerOpportunity.TC_114_CP_Validate_Previbtn_ApplicantStatementpage_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "CP_Previbtn_ApplicantStatementpage_PT");
							driver.quit();
							break;	
							
						case "CP_Nextbtn_ApplicantStatementpage_PT":

							context.setAttribute("fileName", "CP_Nextbtn_ApplicantStatementpage_PT");
							CareerOpportunity.TC_115_CP_Validate_Nextbtn_ApplicantStatementpage_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Nextbtn_ApplicantStatementpage_PT");
							driver.quit();
							break;	
							
						case "CP_Text_Asaconditionofconsideration_AandD_PT":

							context.setAttribute("fileName", "CP_Text_Asaconditionofconsideration_AandD_PT");
							CareerOpportunity.TC_116_CP_Validate_Text_Asaconditionofconsideration_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_Asaconditionofconsideration_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Link_DisputeResolutionRulesandProcedures_AandD_PT":

							context.setAttribute("fileName", "CP_Link_DisputeResolutionRulesandProcedures_AandD_PT");
							CareerOpportunity.TC_117_CP_Validate_Link_DisputeResolutionRulesandProcedures_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "CP_Link_DisputeResolutionRulesandProcedures_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Text_FITNESSINTERNATIONAL_AandD_PT":

							context.setAttribute("fileName", "CP_Text_FITNESSINTERNATIONAL_AandD_PT");
							CareerOpportunity.TC_118_CP_Validate_Text_FITNESSINTERNATIONAL_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_FITNESSINTERNATIONAL_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Text_Irecognizethatdifferences_AandD_PT":

							context.setAttribute("fileName", "CP_Text_Irecognizethatdifferences_AandD_PT");
							CareerOpportunity.TC_119_CP_Validate_Text_Irecognizethatdifferences_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_Irecognizethatdifferences_AandD_PT");
							driver.quit();
							break;	

						case "CP_Text_IUnderStandToOccursLater_AandD_PT":

							context.setAttribute("fileName", "CP_Text_IUnderStandToOccursLater_AandD_PT");
							CareerOpportunity.TC_120_CP_Validate_Text_IUnderStandToOccursLater_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_IUnderStandToOccursLater_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Text_IfurtherunderstandToResolutionAgreement_AandD_PT":

							context.setAttribute("fileName", "CP_Text_IfurtherunderstandToResolutionAgreement_AandD_PT");
							CareerOpportunity.TC_121_CP_Validate_Text_IfurtherunderstandToResolutionAgreement_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_IfurtherunderstandToResolutionAgreement_AandD_PT");
							driver.quit();
							break;	

						case "CP_Text_IHvaeReadAgreement_AandD_PT":

							context.setAttribute("fileName", "CP_Text_IHvaeReadAgreement_AandD_PT");
							CareerOpportunity.TC_122_CP_Validate_Text_IHvaeReadAgreement_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_IHvaeReadAgreement_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Text_IAgreenACKNOWLEDGE_AandD_PT":

							context.setAttribute("fileName", "CP_Text_IAgreenACKNOWLEDGE_AandD_PT");
							CareerOpportunity.TC_123_CP_Validate_Text_IAgreenACKNOWLEDGE_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_IAgreenACKNOWLEDGE_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Text_DateDayYr_AandD_PT":

							context.setAttribute("fileName", "CP_Text_DateDayYr_AandD_PT");
							CareerOpportunity.TC_123_CP_Validate_Text_DateDayYr_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_DateDayYr_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Text_PrintName_AandD_PT":

							context.setAttribute("fileName", "CP_Text_PrintName_AandD_PT");
							CareerOpportunity.TC_124_CP_Validate_Text_PrintName_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_PrintName_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Text_Text_FitnessInternationaLLC_AandD_PT":

							context.setAttribute("fileName", "CP_Text_Text_FitnessInternationaLLC_AandD_PT");
							CareerOpportunity.TC_125_CP_Validate_Text_FitnessInternationaLLC_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_Text_FitnessInternationaLLC_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Img_SignRobert_AandD_PT":

							context.setAttribute("fileName", "CP_Img_SignRobert_AandD_PT");
							CareerOpportunity.TC_126_CP_Validate_Img_SignRobert_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Img_SignRobert_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Text_ByClickingOnBelwbtn_AandD_PT":

							context.setAttribute("fileName", "CP_Text_ByClickingOnBelwbtn_AandD_PT");
							CareerOpportunity.TC_127_CP_Validate_Text_ByClickingOnBelwbtn_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Text_ByClickingOnBelwbtn_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_PrevBtn_ArbitrationnDispute_AandD_PT":

							context.setAttribute("fileName", "CP_PrevBtn_ArbitrationnDispute_AandD_PT");
							CareerOpportunity.TC_128_CP_Validate_PrevBtn_ArbitrationnDispute_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_PrevBtn_ArbitrationnDispute_AandD_PT");
							driver.quit();
							break;	
							
						case "CP_Btn_IAgree_AandD_PT":

							context.setAttribute("fileName", "CP_Btn_IAgree_AandD_PT");
							CareerOpportunity.TC_129_CP_Validate_Btn_IAgree_AandD_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_Btn_IAgree_AandD_PT");
							driver.quit();
							break;	
							
							
						case "CP_input_CertificateNumber_thrice_PT":

							context.setAttribute("fileName", "CP_input_CertificateNumber_thrice_PT");
							CareerOpportunity.TC_131_CP_Validate_input_CertificateNumber_thrice_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_input_CertificateNumber_thrice_PT");
							driver.quit();
							
							break;

						case "CP_RemoveIcon_threeTimes_PT":

							context.setAttribute("fileName", "CP_input_CertificateNumber_thrice_PT");
							CareerOpportunity.TC_132_CP_Validate_RemoveIcon_threeTimes_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_input_CertificateNumber_thrice_PT");
							driver.quit();
							
							break;
						
						case "CP_Popup_Nomorethan3TrainingCertifications_PT":

							context.setAttribute("fileName", "CP_Popup_Nomorethan3TrainingCertifications_PT");
							CareerOpportunity.TC_130_CP_Validate_Popup_Nomorethan3TrainingCertifications_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CP_Popup_Nomorethan3TrainingCertifications_PT");
							driver.quit();
							
							break;
							
						case "CP_onclick_AddEmployer3_PT":

							context.setAttribute("fileName", "CP_onclick_AddEmployer3_PT");
							CareerOpportunity.TC_133_CP_Validate_onclick_AddEmployer3_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_onclick_AddEmployer3_PT");
							driver.quit();
							break;

						case "CP_onclick_RemoveEmployer3_PT":

							context.setAttribute("fileName", "CP_onclick_RemoveEmployer3_PT");
							CareerOpportunity.TC_134_CP_Validate_onclick_RemoveEmployer3_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name );
							context.setAttribute("fileName", "CP_onclick_RemoveEmployer3_PT");
							driver.quit();
							break;
	
						case "CP_text_UrSubmittionWasSuccful_PT":

							context.setAttribute("fileName", "CP_text_UrSubmittionWasSuccful_PT");
							CareerOpportunity.TC_135_CP_Validate_text_UrSubmittionWasSuccful_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_text_UrSubmittionWasSuccful_PT");
							driver.quit();
						break;	
						
						case "CP_text_ThankuforFullsetence_PT":

							context.setAttribute("fileName", "CP_text_ThankuforFullsetence_PT");
							CareerOpportunity.TC_136_CP_Validate_text_ThankuforFullsetence_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_text_ThankuforFullsetence_PT");
							driver.quit();
						break;	
						
						case "CP_text_FitnessLLC_PT":

							context.setAttribute("fileName", "CP_text_FitnessLLC_PT");
							CareerOpportunity.TC_137_CP_Validate_text_FitnessLLC_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_text_FitnessLLC_PT");
							driver.quit();
						break;	

						case "CP_button_PrintUrApplication_PT":

							context.setAttribute("fileName", "CP_button_PrintUrApplication_PT");
							CareerOpportunity.TC_138_CP_Validate_button_PrintUrApplication_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_button_PrintUrApplication_PT");
							driver.quit();
						break;	

						
						
						case "CP_ApplicantLastpage_PT":

							context.setAttribute("fileName", "CP_ApplicantLastpage_PTCP_ApplicantLastpage_PT");
							CareerOpportunity.TC_139_CP_Validate_ApplicantLastpage_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Full_name,From_date,To_date,Leaving_Reason,input_data5,input_data4,input_data2 );
							context.setAttribute("fileName", "CP_ApplicantLastpage_PT");
							driver.quit();
						break;	
						
						
						
						//Pilities Teacher test cases:
						
						
						case "PiTec_text_EmploymentApplication":

							context.setAttribute("fileName", "PiTec_text_EmploymentApplication");
							CareerOpportunity.TC_140_PiTec_Validate_text_EmploymentApplication(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "PiTec_text_EmploymentApplication");
							driver.quit();
							break;
							
						
						case "PiTec_text_Below_EmploymentApp":

							context.setAttribute("fileName", "PiTec_text_Below_EmploymentApp");
							CareerOpportunity.TC_141_PiTec_Validate_Text_Below_EmploymentApp(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "PiTec_text_Below_EmploymentApp");
							driver.quit();
							break;

							
//						case "CP_URL_click_PersonalTrainerApplyhere":
//
//							context.setAttribute("fileName", "CP_URL_click_PersonalTrainerApplyhere");
//							CareerOpportunity.TC_38_CP_Validate_url_clickofPersonalTrainerApplyhere(testdata.get("TextMessage").toString(),Text_input);
//							context.setAttribute("fileName", "CP_URL_click_PersonalTrainerApplyhere");
//							driver.quit();
//							break;

							
						case "PiTec_Hyperlink_www.lafitness.com":

							context.setAttribute("fileName", "PiTec_Hyperlink_www.lafitness.com");
							CareerOpportunity.TC_142_PiTec_Validate_Hyperlink_wwwfitnesscom(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "PiTec_Hyperlink_www.lafitness.com");
							driver.quit();
							break;
							
						case "PiTec_Text_AppInfo_ContandLocInfo":

							context.setAttribute("fileName", "PiTec_Text_AppInfo_ContandLocInfo");
							CareerOpportunity.TC_143_PiTec_Validate_Text_AppInfo_ContandLocInfo(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "PiTec_Text_AppInfo_ContandLocInfo");
							driver.quit();
							break;
							
						case "PiTec_Field_Validation":

							context.setAttribute("fileName", "PiTec_Field_Validation");
							CareerOpportunity.TC_144_PiTec_Validate_mandatoryFields(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "PiTec_Field_Validation");
							driver.quit();	
							break;
							
						case "PiTec_Dropdown_HowDidUHearUs":

							context.setAttribute("fileName", "PiTec_Dropdown_HowDidUHearUs");
							CareerOpportunity.TC_145_PiTec_Validate_Dropdownvalues_HowDidUhearUs(testdata.get("TextMessage").toString(),Dropdown_values);
							context.setAttribute("fileName", "PiTec_Dropdown_HowDidUHearUs");
							driver.quit();	
							break;
							
						case "PiTec_Radio_RU18":

							context.setAttribute("fileName", "PiTec_Radio_RU18");
							CareerOpportunity.TC_146_PiTec_Validate_Radiobutton_RU18(testdata.get("TextMessage").toString(),Dropdown_values);
							context.setAttribute("fileName", "PiTec_Radio_RU18");
							driver.quit();
							break;
							
						case "PiTec_Text_FormatUSCanada":

							context.setAttribute("fileName", "PiTec_Text_FormatUSCanada");
							CareerOpportunity.TC_147_PiTec_validate_Text_FormatUSCanada(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "PiTec_Text_FormatUSCanada");
							driver.quit();
							break;
							
						case "PiTec_Text_Miles":

							context.setAttribute("fileName", "PiTec_Text_Miles");
						CareerOpportunity.TC_148_PiTec_validate_Text_Miles(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "PiTec_Text_Miles");
							driver.quit();
							break;
							
						case "PiTec_Errormsg_CellPhone":

							context.setAttribute("fileName", "PiTec_Errormsg_CellPhone");
							CareerOpportunity.TC_149_PiTec_Validate_ErrorMsg_CellPhone(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "PiTec_Errormsg_CellPhone");
							driver.quit();
							break;
							
							
													
						case "PiTec_Field_inputs":

							context.setAttribute("fileName", "PiTec_Field_inputs");
							CareerOpportunity.TC_150_PiTec_Validate_Field_Input(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode );
							context.setAttribute("fileName", "PiTec_Field_inputs");
							driver.quit();
							break;

							
						case "PiTec_NextButton_ApplicantInfo":

							context.setAttribute("fileName", "PiTec_NextButton_ApplicantInfo");
							CareerOpportunity.TC_151_PiTec_Validate_Button_NextStep(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "PiTec_NextButton_ApplicantInfo");
							driver.quit();
							break;

						case "PiTec_URL_click_PilatesTecherApplyhere":

							context.setAttribute("fileName", "PiTec_URL_click_PilatesTecherApplyhere");
							CareerOpportunity.TC_152_PiTec_Validate_url_clickofPilatesTecherApplyhere(testdata.get("TextMessage").toString(),Text_input);
							context.setAttribute("fileName", "PiTec_URL_click_PilatesTecherApplyhere");
							driver.quit();
							break;

						case "PiTec_Select_RadioNo":

							context.setAttribute("fileName", "PiTec_Select_RadioNo");
							CareerOpportunity.TC_153_PiTec_Verify_YouMustBe18Years_popup_OnselectingRaiodNo(testdata.get("TextMessage").toString(),Dropdown_values,Text_input);
							context.setAttribute("fileName", "PiTec_Select_RadioNo");
							driver.quit();
							break;

						case "PiTec_ClubsinurRadius":

							context.setAttribute("fileName", "PiTec_ClubsinurRadius");
							CareerOpportunity.TC_154_PiTec_Validate_ClubsinurRadius(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode );
							context.setAttribute("fileName", "PiTec_ClubsinurRadius");
							driver.quit();
							break;
	
						case "PiTec_NextButtonClick_ApplicantInfo":

							context.setAttribute("fileName", "PiTec_NextButtonClick_ApplicantInfo");
							CareerOpportunity.TC_155_PiTec_Validate_Nextbutton_ClickofApplicantinfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode );
							context.setAttribute("fileName", "PiTec_NextButtonClick_ApplicantInfo");
							driver.quit();
							break;

						case "PiTec_Text_EducationInfo":

							context.setAttribute("fileName", "PiTec_Text_EducationInfo");
							CareerOpportunity.TC_156_PiTec_Validate_Text_EducationInfo(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input );
							context.setAttribute("fileName", "PiTec_Text_EducationInfo");
							driver.quit();
							break;
							
						case "PiTec_Field_EducationLevel":

							context.setAttribute("fileName", "PiTec_Field_EducationLevel");
							CareerOpportunity.TC_157_PiTec_Field_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input );
							context.setAttribute("fileName", "PiTec_Field_EducationLevel");
							driver.quit();
							break;
							
						case "PiTec_DropdownValues_EducationLevel":

							context.setAttribute("fileName", "PiTec_DropdownValues_EducationLevel");
							CareerOpportunity.TC_158_PiTec_Validate_DropdownValues_EducationLevel(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_DropdownValues_EducationLevel");
							driver.quit();
							break;
							
						case "PiTec_EL_ButtonsPerviousNext":

							context.setAttribute("fileName", "PiTec_EL_ButtonsPerviousNext");
							CareerOpportunity.TC_159_PiTec_Validate_EducationLevel_ButtonsPerviousNext(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode );
							context.setAttribute("fileName", "PiTec_EL_ButtonsPerviousNext");
							driver.quit();
							break;
							
						case "PiTec_EL_ClickofELPreviousbutton":

							context.setAttribute("fileName", "PiTec_EL_ClickofELPreviousbutton");
							CareerOpportunity.TC_160_PiTec_Validate_PreviousPage_ClickofELPreviousbutton(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input );
							context.setAttribute("fileName", "PiTec_EL_ClickofELPreviousbutton");
							driver.quit();
							break;
							
						case "PiTec_EL_ClickofELNextbutton":

							context.setAttribute("fileName", "PiTec_EL_ClickofELNextbutton");
							CareerOpportunity.TC_161_PiTec_Validate_NextPage_ClickofELNextbutton(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_EL_ClickofELNextbutton");
							driver.quit();
							break;
							
						case "PiTec_EL_EducationInfo_ClickofNextbutton":

							context.setAttribute("fileName", "PiTec_EL_EducationInfo_ClickofNextbutton");
							CareerOpportunity.TC_162_PiTec_Validate_EducationInfo_ClickofNextbutton(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_EL_EducationInfo_ClickofNextbutton");
							driver.quit();
							break;

						case "PiTec_Text_ExperienceDetail_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Text_ExperienceDetail_ExperienceInfo");
							CareerOpportunity.TC_163_PiTec_Validate_Text_ExperienceDetail_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_Text_ExperienceDetail_ExperienceInfo");
							driver.quit();
							break;

						case "PiTec_Text_PilatiesTeacher_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Text_PilatiesTeacher_ExperienceInfo");
							CareerOpportunity.TC_164_PiTec_Validate_Text_PilatiesTeacher_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_Text_PilatiesTeacher_ExperienceInfo");
							driver.quit();
							break;
						
						case "PiTec_Field_PilatiesCertificate_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Field_PilatiesCertificate_ExperienceInfo");
							CareerOpportunity.TC_165_Validate_Field_PilatiesCertificate_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_Field_PilatiesCertificate_ExperienceInfo");
							driver.quit();
							break;

						case "PiTec_Radio_PilatiesCertificate_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Radio_PilatiesCertificate_ExperienceInfo");
							CareerOpportunity.TC_166_PiTec_Validate_Radio_PilatiesCertificate_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_Radio_PilatiesCertificate_ExperienceInfo");
							driver.quit();
							break;

						case "PiTec_Link_PilatiesCertifiinfo_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Link_PilatiesCertifiinfo_ExperienceInfo");
							CareerOpportunity.TC_167_PiTec_Validate_Link_PilatiesCertifiinfo_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_Link_PilatiesCertifiinfo_ExperienceInfo");
							driver.quit();
							break;

						
						case "PiTec_Field_PilatiesTeacherExp_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Field_PilatiesTeacherExp_ExperienceInfo");
							CareerOpportunity.TC_168_PiTec_Validate_Field_PilatiesTeacherExp_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_Field_PilatiesTeacherExp_ExperienceInfo");
							driver.quit();
							break;

						case "PiTec_DropdownValues_PilatiesTeacherExp_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_DropdownValues_PilatiesTeacherExp_ExperienceInfo");
							CareerOpportunity.TC_169_PiTec_Validate_Dropdownvalues_PilatiesTeacherExp_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues );
							context.setAttribute("fileName", "PiTec_DropdownValues_PilatiesTeacherExp_ExperienceInfo");
							driver.quit();
							break;
					
						case "PiTec_Text_PilatesCertifications_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Text_PilatesCertifications_ExperienceInfo");
							CareerOpportunity.TC_170_PiTec_Validate_Text_PilatesCertifications_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_Text_PilatesCertifications_ExperienceInfo");
							driver.quit();
							break;
						
						case "PiTec_Text_Pleaseselectnomorethan_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Text_Pleaseselectnomorethan_ExperienceInfo");
							CareerOpportunity.TC_171_PiTec_Validate_Text_Pleaseselectnomorethan_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_Text_Pleaseselectnomorethan_ExperienceInfo");
							driver.quit();
							break;
							
							
						case "PiTec_Fields_CertificationissuedCertificationNumber_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Fields_CertificationissuedCertificationNumber_ExperienceInfo");
							CareerOpportunity.TC_172_PiTec_Validate_Fields_CertificationissuedCertificationNumber_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
							context.setAttribute("fileName", "PiTec_Fields_CertificationissuedCertificationNumber_ExperienceInfo");
							driver.quit();
							break;
							
						case "PiTec_DropdownValue_Certificationissued_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_DropdownValue_Certificationissued_ExperienceInfo");
							CareerOpportunity.TC_173_PiTec_Validate_DropdownValue_Certificationissued_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "PiTec_DropdownValue_Certificationissued_ExperienceInfo");
							driver.quit();
							break;

						case "PiTec_Text_CertificateFilesDtl_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Text_CertificateFilesDtl_ExperienceInfo");
							CareerOpportunity.TC_174_PiTec_Validate_Text_CertificateFilesDtl_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "PiTec_Text_CertificateFilesDtl_ExperienceInfo");
							driver.quit();
							break;
	
						case "PiTec_Validate_Btn_ChooseFile_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Validate_Btn_ChooseFile_ExperienceInfo");
							CareerOpportunity.TC_175_PiTec_Validate_Btn_ChooseFile_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "PiTec_Validate_Btn_ChooseFile_ExperienceInfo");
							driver.quit();
							break;

						case "PiTec_Validate_UploadFileonClickof_ChooseFile_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Validate_UploadFileonClickof_ChooseFile_ExperienceInfo");
							CareerOpportunity.TC_176_PiTec_Validate_UploadFileonClickof_ChooseFile_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "PiTec_Validate_UploadFileonClickof_ChooseFile_ExperienceInfo");
							driver.quit();
							break;
							
						case "PiTec_Validate_Btn_AddCertification_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Validate_Btn_AddCertification_ExperienceInfo");
							CareerOpportunity.TC_177_PiTec_Validate_Btn_AddCertification_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "PiTec_Validate_Btn_AddCertification_ExperienceInfo");
							driver.quit();
							break;

						case "PiTec_Validate_CertificationIssuedBy_onClickof_AddCertification_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Validate_CertificationIssuedBy_onClickof_AddCertification_ExperienceInfo");
							CareerOpportunity.TC_178_PiTec_Validate_CertificationIssuedBy_onClickof_AddCertification_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "PiTec_Validate_CertificationIssuedBy_onClickof_AddCertification_ExperienceInfo");
							driver.quit();
							break;

						case "PiTec_Validate_Popup_Nomorethan3PilatesCertificationscanbeentered_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Validate_Popup_Nomorethan3PilatesCertificationscanbeentered_ExperienceInfo");
							CareerOpportunity.TC_179_PiTec_Validate_Popup_Nomorethan3PilatesCertificationscanbeentered_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "PiTec_Validate_Popup_Nomorethan3PilatesCertificationscanbeentered_ExperienceInfo");
							driver.quit();
							break;

							
						case "PiTec_Validate_OnclickOfDeleteIcon_SectiongetRemoved_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Validate_OnclickOfDeleteIcon_SectiongetRemoved_ExperienceInfo");
							CareerOpportunity.TC_180_PiTec_Validate_OnclickOfDeleteIcon_SectiongetRemoved_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "PiTec_Validate_OnclickOfDeleteIcon_SectiongetRemoved_ExperienceInfo");
							driver.quit();
							break;


						case "PiTec_Validate_Link_PilatesCertificationInformation_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Validate_Link_PilatesCertificationInformation_ExperienceInfo");
							CareerOpportunity.TC_181_PiTec_Validate_Link_PilatesCertificationInformation_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "PiTec_Validate_Link_PilatesCertificationInformation_ExperienceInfo");
							driver.quit();
							break;

						case "PiTec_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo");
							CareerOpportunity.TC_182_PiTec_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "PiTec_Validate_Text_EducationInformation_OnClickoFPrevStepbtn_ExperienceInfo");
							driver.quit();
							break;
							
						case "PiTec_Validate_OnClickoFNextStepbtn_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Validate_OnClickoFNextStepbtn_ExperienceInfo");
							CareerOpportunity.TC_183_PiTec_Validate_OnClickoFNextStepbtn_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_OnClickoFNextStepbtn_ExperienceInfo");
							driver.quit();
							break;

						case "PiTec_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo":

							context.setAttribute("fileName", "PiTec_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo");
							CareerOpportunity.TC_184_PiTec_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Text_EmploymentHistory_OnClickoFNextStepbtn_ExperienceInfo");
							driver.quit();
							break;
							
							
						case "PiTec_Validate_Text_PreviousEmployment_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Text_PreviousEmployment_EmploymentHistory");
							CareerOpportunity.TC_185_PiTec_Validate_Text_PreviousEmployment_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Text_PreviousEmployment_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory");
							CareerOpportunity.TC_186_PiTec_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Radioptn_PreEmploymentnIhvEmphis_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_Field_EmploymentGapExp_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Field_EmploymentGapExp_EmploymentHistory");
							CareerOpportunity.TC_187_PiTec_Validate_Field_EmploymentGapExp_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Field_EmploymentGapExp_EmploymentHistory");
							driver.quit();
							break;

						case "PiTec_Validate_Field_IWillUploadMyResume_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Field_IWillUploadMyResume_EmploymentHistory");
							CareerOpportunity.TC_188_PiTec_Validate_Field_IWillUploadMyResume_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Field_IWillUploadMyResume_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory");
							CareerOpportunity.TC_189_PiTec_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Text_Resume_OnClickofIwillupload_EmploymentHistory");
							driver.quit();
							break;

						case "PiTec_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory");
							CareerOpportunity.TC_190_PiTec_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Text_FileMustbfull_OnClickofIwillupload_EmploymentHistory");
							driver.quit();
							break;

						case "PiTec_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory");
							CareerOpportunity.TC_191_PiTec_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Btn_ChooseFile_OnClickofIwillupload_EmploymentHistory");
							driver.quit();
							break;
							
							
							
						case "PiTec_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory");
							CareerOpportunity.TC_192_PiTec_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EmploymentHistory");
							driver.quit();
							break;

						case "PiTec_Validate_Text_EnterEmpHistory_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Text_EnterEmpHistory_EmploymentHistory");
							CareerOpportunity.TC_193_PiTec_Validate_Text_EnterEmpHistory_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Text_EnterEmpHistory_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_PreviousEmployer1_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Text_PreviousEmployer1_EmploymentHistory");
							CareerOpportunity.TC_194_PiTec_Validate_Text_PreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Text_PreviousEmployer1_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory");
							CareerOpportunity.TC_195_PiTec_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No );
							context.setAttribute("fileName", "PiTec_Validate_Fields_UnderPreviousEmployer1_EmploymentHistory");
							driver.quit();
							break;

						case "PiTec_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory");
							CareerOpportunity.TC_196_PiTec_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_FieldsInputs_UnderPreviousEmployer1_EmploymentHistory");
							driver.quit();
							break;
							
							
						case "PiTec_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory");
							CareerOpportunity.TC_197_PiTec_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Text_BSpecific_NearReasonforLeaving_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory");
							CareerOpportunity.TC_198_PiTec_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Text_ListofJobs_NearEmploymentDetail_EmploymentHistory");
							driver.quit();
							break;

						case "PiTec_Validate_RadioOptions_CanbeContacted_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_RadioOptions_CanbeContacted_EmploymentHistory");
							CareerOpportunity.TC_200_PiTec_Validate_RadioOptions_CanbeContacted_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_RadioOptions_CanbeContacted_EmploymentHistory");
							driver.quit();
							break;

						case "PiTec_Validate_Btn_AddEmployer2_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Btn_AddEmployer2_EmploymentHistory");
							CareerOpportunity.TC_201_PiTec_Validate_Btn_AddEmployer2_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Btn_AddEmployer2_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory");
							CareerOpportunity.TC_202_PiTec_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EmploymentHistory");
							driver.quit();
							break;
							
							
						case "PiTec_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory");
							CareerOpportunity.TC_203_PiTec_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EmploymentHistory");
							driver.quit();
							break;

						case "PiTec_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory");
							CareerOpportunity.TC_204_PiTec_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory");
							CareerOpportunity.TC_205_PiTec_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Btn_RemovEmp3_OnclickAddEmp3_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory");
							CareerOpportunity.TC_206_PiTec_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_OnClick_RemoveEmp3_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_OnClick_RemoveEmp3_EmploymentHistory");
							CareerOpportunity.TC_207_PiTec_Validate_OnClick_RemoveEmp3_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_OnClick_RemoveEmp3_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_OnClick_RemoveEmp2_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_OnClick_RemoveEmp2_EmploymentHistory");
							CareerOpportunity.TC_208_PiTec_Validate_OnClick_RemoveEmp2_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_OnClick_RemoveEmp2_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory");
							CareerOpportunity.TC_209_PiTec_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Txt_ExpInfo_onClickPreviosbtn_EmploymentHistory");
							driver.quit();
							break;
							
						case "PiTec_Validate_onClickNextbtn_EmploymentHistory":

							context.setAttribute("fileName", "PiTec_Validate_onClickNextbtn_EmploymentHistory");
							CareerOpportunity.TC_210_PiTec_Validate_onClickNextbtn_EmploymentHistory(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_onClickNextbtn_EmploymentHistory");
							driver.quit();
							break;
						
						
						case "PiTec_Validate_Text_LanguageSkills_LanguageSkills":

							context.setAttribute("fileName", "PiTec_Validate_Text_LanguageSkills_LanguageSkills");
							CareerOpportunity.TC_211_PiTec_Validate_Text_LanguageSkills_LanguageSkills(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Text_LanguageSkills_LanguageSkills");
							driver.quit();
							break;
									
						case "PiTec_Validate_Text_IncicateLang_LanguageSkills":

							context.setAttribute("fileName", "PiTec_Validate_Text_LanguageSkills_LanguageSkills");
							CareerOpportunity.TC_212_PiTec_Validate_Text_IncicateLang_LanguageSkills(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Text_IncicateLang_LanguageSkills");
							driver.quit();
							break;
						
						case "PiTec_Validate_Languages_LanguageSkills":

							context.setAttribute("fileName", "PiTec_Validate_Languages_LanguageSkills");
							CareerOpportunity.TC_213_PiTec_Validate_Languages_LanguageSkills(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Languages_LanguageSkills");
							driver.quit();
							break;
							
						case "PiTec_Validate_OnClickPrvBtn_LanguageSkills":

							context.setAttribute("fileName", "PiTec_Validate_OnClickPrvBtn_LanguageSkills");
							CareerOpportunity.TC_214_PiTec_Validate_OnClickPrvBtn_LanguageSkills(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_OnClickPrvBtn_LanguageSkills");
							driver.quit();
							break;
							
						case "PiTec_Validate_OnClickNextBtn_LanguageSkills":

							context.setAttribute("fileName", "PiTec_Validate_OnClickNextBtn_LanguageSkills");
							CareerOpportunity.TC_215_PiTec_Validate_OnClickNextBtn_LanguageSkills(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_OnClickNextBtn_LanguageSkills");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_CareerOptions_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_Text_CareerOptions_CareerOption");
							CareerOpportunity.TC_216_TC_PiTec_Validate_Text_CareerOptions_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Text_CareerOptions_CareerOption");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_CrOpporUqualityfor_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_Text_CrOpporUqualityfor_CareerOption");
							CareerOpportunity.TC_217_PiTec_Validate_Text_CrOpporUqualityfor_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Text_CrOpporUqualityfor_CareerOption");
							driver.quit();
							break;

							
						case "PiTec_Validate_Fieldson_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_Fieldson_CareerOption");
							CareerOpportunity.TC_218_PiTec_Validate_Fieldson_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Fieldson_CareerOption");
							driver.quit();
							break;

						case "PiTec_Validate_RadioPartTimeFulltime_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_RadioPartTimeFulltime_CareerOption");
							CareerOpportunity.TC_219_PiTec_Validate_RadioPartTimeFulltime_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_RadioPartTimeFulltime_CareerOption");
							driver.quit();
							break;

						case "PiTec_Validate_CB_PilatiesTeacherDirector_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_CB_PilatiesTeacherDirector_CareerOption");
							CareerOpportunity.TC_220_PiTec_Validate_CB_PilatiesTeacherDirector_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_CB_PilatiesTeacherDirector_CareerOption");
							driver.quit();
							break;
							
						case "PiTec_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption");
							CareerOpportunity.TC_221_PiTec_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_RadioYesNo_RuNoworEverEmployed_CareerOption");
							driver.quit();
							break;

						case "PiTec_Validate_Text_BasedonURsele_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_Text_BasedonURsele_CareerOption");
							CareerOpportunity.TC_222_PiTec_Validate_Text_BasedonURsele_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Text_BasedonURsele_CareerOption");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_IfSReQuestionnaire_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_Text_IfSReQuestionnaire_CareerOption");
							CareerOpportunity.TC_223_PiTec_Validate_Text_IfSReQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Text_IfSReQuestionnaire_CareerOption");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_RehireQuestionnaire_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_Text_RehireQuestionnaire_CareerOption");
							CareerOpportunity.TC_224_PiTec_Validate_Text_RehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Text_RehireQuestionnaire_CareerOption");
							driver.quit();
							break;
							
						case "PiTec_Validate_Fields_UnderRehireQuestionnaire_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_Fields_UnderRehireQuestionnaire_CareerOption");
							CareerOpportunity.TC_225_PiTec_Validate_Fields_UnderRehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date );
							context.setAttribute("fileName", "PiTec_Validate_Fields_UnderRehireQuestionnaire_CareerOption");
							driver.quit();
							break;
							
						case "PiTec_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption");
							CareerOpportunity.TC_226_PiTec_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "PiTec_Validate_FieldInputs_UnderRehireQuestionnaire_CareerOption");
							driver.quit();
							break;
							
						case "PiTec_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption");
							CareerOpportunity.TC_227_PiTec_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "PiTec_Validate_Dropdown_HwdidUresignEmpwitUs_CareerOption");
							driver.quit();
							break;
							
							
						case "PiTec_Validate_OnClickPrvBtn_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_OnClickPrvBtn_CareerOption");
							CareerOpportunity.TC_228_PiTec_Validate_OnClickPrvBtn_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "PiTec_Validate_OnClickPrvBtn_CareerOption");
							driver.quit();
							break;

						case "PiTec_Validate_OnClickNextBtn_CareerOption":

							context.setAttribute("fileName", "PiTec_Validate_OnClickNextBtn_CareerOption");
							CareerOpportunity.TC_229_PiTec_Validate_OnClickNextBtn_CareerOption(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "PiTec_Validate_OnClickNextBtn_CareerOption");
							driver.quit();
							break;
							
							
						case "PiTec_Validate_Text_EqualOpportunityEmpy_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Text_EqualOpportunityEmpy_EOE");
							CareerOpportunity.TC_230_PiTec_Validate_Text_EqualOpportunityEmpy_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "PiTec_Validate_Text_EqualOpportunityEmpy_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_TheCompanyisan_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Text_TheCompanyisan_EOE");
							CareerOpportunity.TC_231_PiTec_Validate_Text_TheCompanyisan_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "PiTec_Validate_Text_TheCompanyisan_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_CompletionOfForm_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Text_CompletionOfForm_EOE");
							CareerOpportunity.TC_232_PiTec_Validate_Text_CompletionOfForm_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "PiTec_Validate_Text_CompletionOfForm_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_Fields_EqualOpportunityEmploymentSection_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Fields_EqualOpportunityEmploymentSection_EOE");
							CareerOpportunity.TC_233_PiTec_Validate_Fields_EqualOpportunityEmploymentSection_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason );
							context.setAttribute("fileName", "PiTec_Validate_Fields_EqualOpportunityEmploymentSection_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_DDValues_WtisUrGender_EOE":

							context.setAttribute("fileName", "PiTec_Validate_DDValues_WtisUrGender_EOE");
							CareerOpportunity.TC_234_PiTec_Validate_DDValues_WtisUrGender_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5 );
							context.setAttribute("fileName", "PiTec_Validate_DDValues_WtisUrGender_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_DDValues_WtyourRaceEthnicOrigin_EOE":

							context.setAttribute("fileName", "PiTec_Validate_DDValues_WtyourRaceEthnicOrigin_EOE");
							CareerOpportunity.TC_235_PiTec_Validate_DDValues_WtyourRaceEthnicOrigin_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_DDValues_WtyourRaceEthnicOrigin_EOE");
							driver.quit();
							break;

						case "PiTec_Validate_Text_HispanicorLatino_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Text_HispanicorLatino_EOE");
							CareerOpportunity.TC_236_PiTec_Validate_Text_HispanicorLatino_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_Text_HispanicorLatino_EOE");
							driver.quit();
							break;

						case "PiTec_Validate_Text_WhiteNotHispanicorLatino_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Text_WhiteNotHispanicorLatino_EOE");
							CareerOpportunity.TC_237_PiTec_Validate_Text_WhiteNotHispanicorLatino_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_Text_WhiteNotHispanicorLatino_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_BlackorAfricanAmerican_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Text_BlackorAfricanAmerican_EOE");
							CareerOpportunity.TC_238_PiTec_Validate_Text_BlackorAfricanAmerican_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_Text_BlackorAfricanAmerican_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_NativeHawaiianorOtherPacific_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Text_NativeHawaiianorOtherPacific_EOE");
							CareerOpportunity.TC_239_PiTec_Validate_Text_NativeHawaiianorOtherPacific_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_Text_NativeHawaiianorOtherPacific_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_AsianNotHispanicorLatino_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Text_AsianNotHispanicorLatino_EOE");
							CareerOpportunity.TC_240_PiTec_Validate_Text_AsianNotHispanicorLatino_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_Text_AsianNotHispanicorLatino_EOE");
							driver.quit();
							break;
							

						case "PiTec_Validate_Text_AmericanIndianorAlaskanNative_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Text_AmericanIndianorAlaskanNative_EOE");
							CareerOpportunity.TC_241_PiTec_Validate_Text_AmericanIndianorAlaskanNative_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_Text_AmericanIndianorAlaskanNative_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_Allpersonswho_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Text_Allpersonswho_EOE");
							CareerOpportunity.TC_242_PiTec_Validate_Text_Allpersonswho_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_Text_Allpersonswho_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE");
							CareerOpportunity.TC_243_PiTec_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE");
							driver.quit();
							break;

						case "PiTec_Validate_Fieldinputs_EOE":

							context.setAttribute("fileName", "PiTec_Validate_Fieldinputs_EOE");
							CareerOpportunity.TC_244_PiTec_Validate_Fieldinputs_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_Fieldinputs_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_PreviBtn_EOE":

							context.setAttribute("fileName", "PiTec_Validate_PreviBtn_EOE");
							CareerOpportunity.TC_245_PiTec_Validate_PreviBtn_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_PreviBtn_EOE");
							driver.quit();
							break;
							
							
						case "PiTec_Validate_NextBtn_EOE":

							context.setAttribute("fileName", "PiTec_Validate_NextBtn_EOE");
							CareerOpportunity.TC_246_PiTec_Validate_NextBtn_EOE(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_NextBtn_EOE");
							driver.quit();
							break;
							
						case "PiTec_Validate_Text_ApplicationStatement_AppliSatement":

							context.setAttribute("fileName", "PiTec_Validate_Text_ApplicationStatement_AppliSatement");
							CareerOpportunity.TC_247_PiTec_Validate_Text_ApplicationStatement_AppliSatement(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
							context.setAttribute("fileName", "PiTec_Validate_Text_ApplicationStatement_AppliSatement");
							driver.quit();
							break;
							
							
							case "PiTec_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement":

								context.setAttribute("fileName", "PiTec_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement");
								CareerOpportunity.TC_248_PiTec_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
								context.setAttribute("fileName", "PiTec_Validate_Text_ThisApplicationCompleteParaOnApplicantStatement");
								driver.quit();
								break;
								
								
							case "PiTec_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage":

								context.setAttribute("fileName", "PiTec_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage");
								CareerOpportunity.TC_249_PiTec_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
								context.setAttribute("fileName", "PiTec_Validate_input_FirstNameLastName_acknowledgelineofApplicantStatementpage");
								driver.quit();
								break;
								
								
								
		
							case "PiTec_Validate_text_Iacknowledge_ApplicantStatementpage":

								context.setAttribute("fileName", "PiTec_Validate_text_Iacknowledge_ApplicantStatementpage");
								CareerOpportunity.TC_250_PiTec_Validate_text_Iacknowledge_ApplicantStatementpage(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
								context.setAttribute("fileName", "PiTec_Validate_text_Iacknowledge_ApplicantStatementpage");
								driver.quit();
								break;
								

							
						case "PiTec_Validate_Previbtn_ApplicantStatementpage":

								context.setAttribute("fileName", "PiTec_Validate_Previbtn_ApplicantStatementpage");
								CareerOpportunity.TC_251_PiTec_Validate_Previbtn_ApplicantStatementpage(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
								context.setAttribute("fileName", "PiTec_Validate_Previbtn_ApplicantStatementpage");
								driver.quit();
								break;
								
							case "PiTec_Validate_Nextbtn_ApplicantStatementpage":

								context.setAttribute("fileName", "PiTec_Validate_Nextbtn_ApplicantStatementpage");
								CareerOpportunity.TC_252_PiTec_Validate_Nextbtn_ApplicantStatementpage(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
								context.setAttribute("fileName", "PiTec_Validate_Nextbtn_ApplicantStatementpage");
								driver.quit();
								break;
								
							case "PiTec_Validate_Text_ArbitationnDispute_AandD":

								context.setAttribute("fileName", "PiTec_Validate_Text_ArbitationnDispute_AandD");
								CareerOpportunity.TC_253_PiTec_Validate_Text_ArbitationnDispute_AandD(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
								context.setAttribute("fileName", "PiTec_Validate_Text_ArbitationnDispute_AandD");
								driver.quit();
								break;
								
							case "PiTec_Validate_Text_Asaconditionofconsideration_Aand":

								context.setAttribute("fileName", "PiTec_Validate_Text_Asaconditionofconsideration_Aand");
								CareerOpportunity.TC_254_PiTec_Validate_Text_Asaconditionofconsideration_AandD(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
								context.setAttribute("fileName", "PiTec_Validate_Text_Asaconditionofconsideration_Aand");
								driver.quit();
								break;

								
							case "PiTec_Validate_Link_DisputeResolutionRulesandProcedures_AandD":

								context.setAttribute("fileName", "PiTec_Validate_Link_DisputeResolutionRulesandProcedures_AandD");
								CareerOpportunity.TC_255_PiTec_Validate_Link_DisputeResolutionRulesandProcedures_AandD(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
								context.setAttribute("fileName", "PiTec_Validate_Link_DisputeResolutionRulesandProcedures_AandD");
								driver.quit();
								break;

							case "PiTec_Validate_Text_FITNESSINTERNATIONAL_AandD":

								context.setAttribute("fileName", "PiTec_Validate_Link_DisputeResolutionRulesandProcedures_AandD");
								CareerOpportunity.TC_256_PiTec_Validate_Text_FITNESSINTERNATIONAL_AandD(testdata.get("TextMessage").toString(),Text_input,Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Certificate_No,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
								context.setAttribute("fileName", "PiTec_Validate_Link_DisputeResolutionRulesandProcedures_AandD");
								driver.quit();
								break;
												
							
	//					*/
	
						
						
					default:
						driver.quit();
						break;
	
					}
	
					// EndTest
	//				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
					ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
					ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
					ExtentTestManager.endTest();
					ExtentManager.getInstance().flush();
					Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
					Log.info("Browser is closed");
	
	
				}
	
			} 
			catch (Exception e)
			{
				Thread.sleep(1000);
				ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				String stackTrace = Throwables.getStackTraceAsString(e);
				Log.error( stackTrace);
			
				
				String fileName = (String) context.getAttribute("fileName");
	
				try {
					File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
							testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().fail(e.getMessage(),
							MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
					ExtentTestManager.getTest().log(Status.FAIL, e);
					} 
				catch (Exception e1) {
					System.out.println("File not found " + e1);
									}
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	
	//			 Logout
				context.setAttribute("fileName", "Logout");
				if (com.test.user.All_scenarios.driver!=null)driver.quit();
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				Log.info("Browser is closed");
	
				// EndTest
				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				throw new Exception(stackTrace);
			} 
			catch (AssertionError e) 
			{
				Thread.sleep(1000);
	//			System.out.println("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				String stackTrace = Throwables.getStackTraceAsString(e);
				Log.error( stackTrace);
				
				String fileName = (String) context.getAttribute("fileName");
	
				try {
					File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
							testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().fail(e.getMessage(),
							MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
					ExtentTestManager.getTest().log(Status.FAIL, e);
					} 
				catch (Exception e1)
				{
					System.out.println("File not found " + e1);
				}
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	
				// Logout
				context.setAttribute("fileName", "Logout");
				driver.quit();
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				Log.info("Browser is closed");
	
				// EndTest
				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				
				throw new Exception(stackTrace);
				
			}
		}
	
	
		
		@DataProvider(name = "TestData")
		public static Object[][] gettestdate() throws IOException {
	
			Object[][] objectarry = null;
			java.util.List<Map<String, String>> completedata = com.Utility.ExcelReader.getdata("Career_opportunities");
	
			java.util.List<Map<String, String>> completedata1 = new ArrayList<Map<String,String>>();
			int j=0;
	
			for (int i = 0; i < completedata.size(); i++) {
				if(completedata.get(i).get("Run").toString().equalsIgnoreCase("Yes")) 
				{
				completedata1.add(j, completedata.get(i));
				j++;
				}
			}
			
			objectarry = new Object[completedata1.size()][1];
			
			for (int i = 0; i < completedata1.size(); i++) {
				objectarry[i][0] = completedata1.get(i);
			}
			return objectarry;
	
		}
	
		public void Takescreenshot(String fileName, String scenario) {
			try {
				File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
						scenario);
				ExtentTestManager.getTest().pass("File upload screenshot",
						MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
				
				} 
			catch (Exception e1) {
				System.out.println("File not found " + e1);
								}
		}
		
	}
